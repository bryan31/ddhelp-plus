set echo off

DEPLOY_DIR=`pwd`
JAVA_CMD=$DEPLOY_DIR/jre/bin/java

$JAVA_CMD -jar ddhelp-plus.jar

echo 按任意键继续
read -n 1